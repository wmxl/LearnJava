package HuHomework.log;

public interface trigger {
    public void action();
    public boolean isLegal();
}
